import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {observer} from "mobx-react-lite";
import {authStore} from "../../../stores/authStore.js";
import axios from 'axios';
import Logo from '../../../assets/auth_logo.svg';
import './Login.scss';

export default function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://127.0.0.1:8000/api/user/login/', { email, password });
            if (response.status === 200) {
                // успешная авторизация
                console.log(response.data)
                navigate('/'); // Замените '/dashboard' на путь к вашей защищенной странице
            } else {
                // обработка ошибок
                setErrorMessage(response.data.message || 'Ошибка авторизации');
            }
        } catch (error) {
            setErrorMessage(error.response?.data?.message || 'Ошибка подключения к серверу');
        }
    };

    return (
        <div className="container">
            <div className="main">
                <form className="login-form" onSubmit={handleSubmit}>
                    <img className="auth__logo" src={Logo} alt="Логотип" />
                    <h3 className="login__header">Авторизация</h3>
                    <input
                        className="form-input"
                        type="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                    <input
                        className="form-input"
                        type="password"
                        placeholder="Пароль"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                    {errorMessage && <p className="error-message">{errorMessage}</p>}
                    <button type="submit" className="form-submit">Войти</button>
                    <p className="register-prompt">Нет аккаунта? <Link to="/register"><span>Зарегистрироваться</span></Link></p>
                </form>
            </div>
        </div>
    );
}
