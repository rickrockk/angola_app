import React from "react";

export function MedicalInsuranceData() {
    return (
        <div className="profile-section">
            <h2 className="profile-title">Полис</h2>
            <div className="profile-details">
                <p className="profile-item">
                    <span className="profile-label">Номер полиса:</span> 1234567890123456
                </p>
                <p className="profile-item">
                    <span className="profile-label">Страховая компания:</span> Росгосстрах
                </p>
            </div>
        </div>
    )
}