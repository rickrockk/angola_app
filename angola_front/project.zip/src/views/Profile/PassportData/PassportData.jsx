import React from "react";

export function PassportData() {
    return (
        <div className="profile-section">
            <h2 className="profile-title">Паспортные данные</h2>
            <div className="profile-details">
                <p className="profile-item">
                    <span className="profile-label">Серия и номер:</span> 1234 567890
                </p>
                <p className="profile-item">
                    <span className="profile-label">Дата выдачи:</span> 01.01.2000
                </p>
                <p className="profile-item">
                    <span className="profile-label">Кем выдан:</span> Отделом УФМС России
                </p>
            </div>
        </div>
    )
}