import React from 'react';
import './Profile.scss';
import {PassportData} from "./PassportData/PassportData.jsx";
import {MedicalInsuranceData} from "./MedicalInsuranceData/MedicalInsuranceData.jsx";

export default function Profile() {
    return (
        <div className="profile-container">
            <h1 className="profile-header">Профиль</h1>
            <div className="profile-content">
                <div className="profile-section">
                    <h2 className="profile-title">Учётная запись</h2>
                    <div className="profile-details">
                        <img className="profile-avatar" src="path-to-avatar" alt="Аватар" />
                        <div className="profile-info">
                            <h3 className="profile-name">Королёв Кирилл Витальевич</h3>
                            <p className="profile-status">Подтверждённая учётная запись</p>
                            <p className="profile-item">
                                <span className="profile-label">Телефон:</span> +7 930 300-16-39 <span className="profile-edit">Изменить</span>
                            </p>
                            <p className="profile-item">
                                <span className="profile-label">Email:</span> mrkillraider@yandex.ru <span className="profile-edit">Изменить</span>
                            </p>
                            <a href="#" className="profile-link">Как обезопасить свою учётную запись на Госуслугах</a>
                            <a href="#" className="profile-link">Сменить пароль</a>
                            <a href="#" className="profile-link">Удалить учётную запись</a>
                        </div>
                    </div>
                </div>
                <div className="profile__documents">
                    <PassportData/>
                    <MedicalInsuranceData/>
                </div>
            </div>
        </div>
    );
};
