import { makeAutoObservable } from "mobx";
import axios from 'axios';

class AuthStore {
    user = null;

    constructor() {
        makeAutoObservable(this);
    }

    login = async (credentials) => {
        try {
            const response = await axios.post('https://your-api-endpoint.com/login', credentials);
            if (response.status === 200) {
                this.user = { email: credentials.email }; // Сохраните необходимую информацию о пользователе
            }
            console.log(response.data)
        } catch (error) {
            throw error;
        }
    };

    register = async (data) => {
        try {
            const response = await axios.post('http://127.0.0.1:8000/api/user/register/', data);
            if (response.status === 200) {
                this.user = response.data;
            }
        } catch (error) {
            throw error;
        }
    };


    logout = () => {
        this.user = null;
    };

    get isAuthenticated() {
        return this.user !== null;
    }
}

export const authStore = new AuthStore();
