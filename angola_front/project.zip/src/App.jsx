import {BrowserRouter, Routes, Route} from "react-router-dom";
import {Header} from "./components/Header/Header.jsx";
import Footer from "./components/Footer/Footer.jsx";
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.scss'
import Home from "./views/Home/Home.jsx";
import Auth from "./views/Auth/Auth.jsx";
import Profile from "./views/Profile/Profile.jsx";
import Appointment from "./views/Appointment/Appointment";
import DocsRecovery from "./views/DocumentsRecovery/DocsRecovery";
import Notifications from "./views/Notifications/Notifications";
import Registration from "./views/Auth/Registration/Registration";
import Login from "./views/Auth/Login/Login";

function App() {

  return (
    <div className="app">
        <BrowserRouter>
            <Header/>
            <Routes>
                <Route path="/" element={<Home/>}/>
                <Route path="/appointment" element={<Appointment/>}/>
                <Route path="/docs_recovery" element={<DocsRecovery/>}/>
                <Route path="/notifications" element={<Notifications/>}/>
                <Route path="/auth" element={<Auth/>}/>
                <Route path="/profile" element={<Profile/>}/>
                <Route path="/register" element={<Registration/>}/>
                <Route path="/login" element={<Login/>}/>
            </Routes>
        </BrowserRouter>
    </div>
  )
}

export default App
