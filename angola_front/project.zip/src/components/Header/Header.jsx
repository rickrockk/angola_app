import './Header.scss'
import {Link} from "react-router-dom";
import SearchIcon from '../../assets/Search.svg'
import Logo from '../../assets/logo.svg'

export function Header() {
    return (
        <header className='header'>
            <Link to="/">
                <img src={Logo} alt='Логотип' className='header__logo'/>
            </Link>
            <nav className="header__nav">
                <ul className="nav__list">
                    <li className="nav__item">
                        <Link to='/notifications'>
                            Уведомления
                        </Link>
                    </li>
                    <li className="nav__item">
                        <Link to='/docs_recovery'>
                            Документы
                        </Link>
                    </li>
                    <li className="nav__item">
                        <Link to='/appointment'>
                            Заявления
                        </Link>
                    </li>
                    <li className="nav__item">
                        <Link to='/'>
                            Платежи
                        </Link>
                    </li>
                    <li className="nav__item">
                        <Link to='/'>
                            Помощь
                        </Link>
                    </li>
                    <li className="nav__item">
                        <div className="nav__search-login">
                            <img src={SearchIcon} alt='Поиск' className='search'/>
                            <span className="login__link">
                                <Link to="/auth">
                                    Войти
                                </Link>
                            </span>
                        </div>
                    </li>
                </ul>
            </nav>
        </header>
    )
}